package com.dvtt.demo.coredemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CoreDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(CoreDemoApplication.class, args);
	}

}
