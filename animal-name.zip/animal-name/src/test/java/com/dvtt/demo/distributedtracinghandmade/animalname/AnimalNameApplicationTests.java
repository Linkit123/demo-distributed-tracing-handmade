package com.dvtt.demo.distributedtracinghandmade.animalname;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AnimalNameApplicationTests {

	@Test
	void contextLoads() {
	}

}
