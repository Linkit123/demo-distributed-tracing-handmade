package com.dvtt.demo.distributedtracinghandmade.animalname;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AnimalNameApplication {

	public static void main(String[] args) {
		SpringApplication.run(AnimalNameApplication.class, args);
	}

}
