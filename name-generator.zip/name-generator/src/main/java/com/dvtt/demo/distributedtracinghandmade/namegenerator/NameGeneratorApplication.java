package com.dvtt.demo.distributedtracinghandmade.namegenerator;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NameGeneratorApplication {

	public static void main(String[] args) {
		SpringApplication.run(NameGeneratorApplication.class, args);
	}

}
