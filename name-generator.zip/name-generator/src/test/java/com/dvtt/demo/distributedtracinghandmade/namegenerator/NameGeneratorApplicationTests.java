package com.dvtt.demo.distributedtracinghandmade.namegenerator;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NameGeneratorApplicationTests {

	@Test
	void contextLoads() {
	}

}
