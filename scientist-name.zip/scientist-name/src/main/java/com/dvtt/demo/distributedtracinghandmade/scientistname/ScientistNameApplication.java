package com.dvtt.demo.distributedtracinghandmade.scientistname;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ScientistNameApplication {

	public static void main(String[] args) {
		SpringApplication.run(ScientistNameApplication.class, args);
	}

}
